console.log("Debug statement: statement.js loaded");

// static/src/js/first_module.js
openerp.shipment = function (instance) {
    console.log("Shipment Module loaded");
    //instance.web.client_actions.add('example.action', 'instance.web_example.action');
    /*instance.web_example.action = function (parent, action) {
        console.log("Executed the action", action);
    };*/

 };