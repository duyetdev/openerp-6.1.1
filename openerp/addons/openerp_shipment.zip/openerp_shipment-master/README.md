openerp_shipment
================

Description
